gcc ftl_pagemap.c ftl_blockmap.c main.c nand.c -o ftlsim
